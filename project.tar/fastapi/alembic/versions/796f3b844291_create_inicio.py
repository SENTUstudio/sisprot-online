"""create inicio

Revision ID: 796f3b844291
Revises: 
Create Date: 2023-07-18 14:10:01.130431

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '796f3b844291'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
