"""Add a column

Revision ID: 7c6446204f36
Revises: 796f3b844291
Create Date: 2023-07-18 14:13:11.727768

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7c6446204f36'
down_revision = '796f3b844291'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
