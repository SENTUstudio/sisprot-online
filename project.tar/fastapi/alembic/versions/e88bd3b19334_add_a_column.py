"""Add a column

Revision ID: e88bd3b19334
Revises: 7c6446204f36
Create Date: 2023-07-18 14:18:12.107435

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e88bd3b19334'
down_revision = '7c6446204f36'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
