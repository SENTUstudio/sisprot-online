136  git pull origin master
  137  pm2 restart sisprot_online
  138  pm2 logs
  139  ls
  140  pwd
  141  crontab -e
  142  ls
  143  source .venv/bin/activate
  144  ls
  145  python sisprot/tasks/generar_tasa_cambiaria.py
  146  pip install -r requirements.txt
  147  python sisprot/tasks/generar_tasa_cambiaria.py
  148  pip install requests
  149  python sisprot/tasks/generar_tasa_cambiaria.py
  150  date
  151  sudo timedatectl set-time '18:25:30'
  152  sudo dpkg-reconfigure tzdata
  153  date
  154  python sisprot/tasks/generar_tasa_cambiaria.py
  155  crontab -e
  156  pwd
  157  crontab -e
  158  python sisprot/tasks/generar_tasa_cambiaria.py
  159  clear
  160  psql -h localhost -U sisprot -d sisprot_db
  161  clear
  162  psql -h localhost -U sisprot -d sisprot_db
  163  ls
  164  cd apps/
  165  ls
  166  cd sisprot-online/
  167  git pull origin master
  168  pm2 restart sisprot_online
  169  ls
  170  source .venv/bin/activate
  171  pm2 --name=generar_tasa --no-autorestart start "pyton sisprot/tasks/generar_tasa_cambiaria.py"
  172  pm2 --name=generar_tasa --no-autorestart start "python sisprot/tasks/generar_tasa_cambiaria.py"
  173  pm2 monit
  174  pm2 lgs
  175  pm2 ls
  176  pm2 start generar_tasa
  177  pm2 ls
  178  pm2
  179  pm2 -h
  180  pm2 ls
  181  pm2 delete 1
  182  pm2 delete 2
  183  pm2 --name=generar_tasa --no-autorestart start "python sisprot/tasks/generar_tasa_cambiaria.py"
  184  pm2 ls
  185  crontab -e
  186  which pm2
  187  crontab -e
  188  ls
  189  pm2
  190  pm2 ls
  191  pm2 logs
  192  less /home/software/.pm2/logs/sisprot-online-out.log
  193  pm2 start generar
  194  pm2 start generar_tasa
  195  pm2 logs
  196  crontab -e
  197  sudo crontab -e
  198  pm2 logs
  199  ip a
  200  curl ifconfig.me
  201  pm2 logs
  202  sudo crontab -l
  203  sudo nano /etc/rsyslog.conf
  204  sudo systemctl restart rsyslog
  205  sudo systemctl restart cron
  206  sudo systemctl status cron
  207  less /var/log/cron.log
  208  sudo crontab -e
  209  less /var/log/cronrun
  210  which pm2
  211  node --version
  212  which node
  213  sudo systemctl status cron
  214  less /var/log/cronrun
  215  sudo su
  216  sudo crontab -e
  217  cd ..
  218  sudo crontab -e
  219  crontab -e
  220  nano generar_tasa.sh
  221  ./generar_tasa.sh
  222  nano generar_tasa.sh
  223  ./generar_tasa.sh
  224  pm2 save
  225  crontab -e
  226  sudo systemctl status cron
  227  less /var/log/cronrun
  228  cd apps/sisprot-online/
  229  pwd
  230  http://home/software/apps/sisprot-online/.venv/bin/python%20/home/software/apps/sisprot-online/sisprot/tasks/generar_tasa.py
  231  home/software/apps/sisprot-online/.venv/bin/python%20/home/software/apps/sisprot-online/sisprot/tasks/generar_tasa.py
  232  /home/software/apps/sisprot-online/.venv/bin/python /home/software/apps/sisprot-online/sisprot/tasks/generar_tasa.py
  233  cd sisprot/tasks/
  234  ls
  235  /home/software/apps/sisprot-online/.venv/bin/python /home/software/apps/sisprot-online/sisprot/tasks/generar_tasa_cambiaria.py
  236  crontab -e
  237  nano ~/generar_tasa.sh
  238  less /var/log/cronrun
  239  sudo systemctl status cron
  240  crontab -e
  241  ls
  242  crontab -e
  243  ls
  244  sudo systemctl status cron
  245  less /var/log/cronrun
  246  sudo su
  247  nano generar_tasa.sh
  248  sudo su
  249  nano generar_tasa.sh
  250  ./generar_tasa.sh
  251  sudo su
  252  ls
  253  cat .bashrc
  254  node --help
  255  touch generar_tasa.sh
  256  nano generar_tasa.sh
  257  chmod +x generar_tasa.sh
  258  ./generar_tasa.sh
  259  nano generar_tasa.sh
  260  ./generar_tasa.sh
  261  sudo su
  262  cd apps/
  263  ls
  264  cd sisprot-online/
  265  git pull origin master
  266  pm2 restart sisprot_online
  267  pm2 logs
  268  ls
  269  cd apps/
  270  ls
  271  cd sisprot-online/
  272  git pull origin master
  273  pm2 restart sisprot_online
  274  ls
  275  cd apps/
  276  git pull origin master
  277  ls
  278  cd sisprot-online/
  279  git pull origin master
  280  pm2 restart sisprot_online
  281  pm2 monit
  282  git status
  283  ls
  284  git pull origin master
  285  pm2 monit
  286  git pull origin master
  287  pm2 restart 360control_backend
  288  pm2 restart sisprot_online
  289  pm2 logs
  290  ls
  291  cd apps/
  292  ls
  293  cd sisprot-online/
  294  ls
  295  git pull origin master
  296  pm2 restart sisprot_online
  297  pm2 monit
  298  ls
  299  cd apps/
  300  ls
  301  cd sisprot-online/
  302  ls
  303  git pull origin master
  304  pm2 restart sisprot_online
  305  ls
  306  sudo crontab -e
  307  cd ..
  308  ls
  309  cd sisprot-online/
  310  ls
  311  source .venv/bin/activate
  312  ls
  313  cd sisprot/
  314  ls
  315  cd tasks/
  316  ls
  317  cat generar_tasa_cambiaria.py
  318  python generar_tasa_cambiaria.py
  319  curl https://petroapp-price.petro.gob.ve/price
  320  curl https://bcv.org.ve
  321  curl http://www.bcv.org.ve/
  322  python
  323  cd apps/sisprot-online/
  324  git pull origin master
  325  source .venv/bin/activate
  326  pip install -r requirements.txt
  327  sudo crontab -e
  328  python sisprot/tasks/generar_tasa_cambiaria.py
  329  pm2 restart sisprot_online
  330  pm2 logs
  331  ls
  332  ls
  333  sudo systemctl status cron
  334  sudo crontab -e
  335  cd apps/
  336  cd sisprot-online/
  337  git pull origin master
  338  ls
  339  source .venv/bin/activate
  340  python sisprot/tasks/generar_tasa_cambiaria.py
  341  sudo snap install core; sudo snap refresh core
  342  sudo snap install --classic certbot
  343  sudo ln -s /snap/bin/certbot /usr/bin/certbot
  344  cat /etc/nginx/sites-available/
  345  cat /etc/nginx/sites-available/default
  346  cd /etc/nginx/sites-available/
  347  ls
  348  less default
  349  sudo nano default
  350  sudo certbot --nginx
  351  ls
  352  cd apps/
  353  ls
  354  cd sisprot-online/
  355  s
  356  ls
  357  git pull origin master
  358  pm2 restart sisprot_online
  359  pm2 logs
  360  git pull origin master
  361  pm2 restart sisprot_online
  362  pm2 logs
  363  pqsl -h localhost -u sisprot -d sisprot_db
  364  psql -h localhost -u sisprot -d sisprot_db
  365  su postgres
  366  psql -H localhost -U sisprot -D sisprot_db
  367  ls
  368  cd apps/
  369  ls
  370  cd sisprot-online/
  371  ls
  372  git pull origin master
  373  ls
  374  git pull origin master
  375  ls
  376  pm2 restart sisprot_online
  377  pm2 logs
  378  pm2 restart sisprot_online
  379  git pull origin master
  380  less sisprot/schemas/__init__.py
  381  cd apps/
  382  cd sisprot-online/
  383  ls
  384  git pull origin master
  385  pm2 restart sisprot_online
  386  git pull origin master
  387  pm2 restart sisprot_online
  388  git status
  389  git pull origin master
  390  pm2 restart sisprot_online
  391  ls
  392  cd apps/
  393  ls
  394  cd sisprot-online/
  395  git pull origin master
  396  pm2 restart sisprot_online
  397  pm2 logs
  398  git pull origin master
  399  ls
  400  pm2 restart sisprot_online
  401  pm2 logsd
  402  pm2 logs
  403  git pull origin master
  404  pm2 restart sisprot_online
  405  pm2 logs
  406  git pull origin master
  407  pm2 restart sisprot_online
  408  git pull origin master
  409  pm2 restart sisprot_online
  410  pm2 logs
  411  history
  412  sudo history
  413  cd apps/
  414  ls
  415  cd sisprot-online/
  416  git pull origin master
  417  pm2 restart sisprot_online
  418  pm2 logs
  419  pm2 restart sisprot_online
  420  pm2 logs
  421  cd ..
  422  ls
  423  cd apps/sisprot-online/
  424  git pull origin master
  425  pm2 restart sisprot_online
  426  git pull origin master
  427  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
  428  git pull origin master
  429  pm2 restart sisprot_online
  430  pm2 logs
  431  ls
  432  pm2 logs
  433  ls
  434  cd apps/sisprot-online/
  435  git pull origin master
  436  pm2 restart sisprot_online
  437  pm2 logs
  438  ls
  439  psql -h localhost -U sisprot -d sisprot_db
  440  clear
  441  psql -h localhost -U sisprot -d sisprot_db
  442  clear
  443  psql -h localhost -U sisprot -d sisprot_db
  444  ls
  445  cd apps/
  446  ls
  447  cd sisprot-online/
  448  ls
  449  git pull origin master
  450  pm2 restart sisprot_online
  451  pm2 ls
  452  pm2 logs
  453  ls
  454  cd apps/
  455  ls
  456  exit
  457  ls
  458  cd apps/
  459  lñs
  460  ls
  461  cd sisprot-online/
  462  git pull origin master
  463  pm2 restart sisprot_online
  464  pm2 logs
  465  pm2 restart sisprot_online
  466  pm2 logs
  467  ps aux
  468  ip add
  469  df /h
  470  df -h
  471  ip addr
  472  exit
  473  ls
  474  cd apps/
  475  ls
  476  cd sisprot-online/
  477  git pull origin master
  478  pm2
  479  pm2 restart sisprot-backend
  480  pm2 ls
  481  pm2 restart sisprot_online
  482  pm2 logs
  483  cat /etc/nginx/sites-available/default
  484  cd /etc/nginx/sites-available/
  485  ls
  486  cd ..
  487  less nginx.conf
  488  ls
  489  cd apps/
  490  ks
  491  ls
  492  pm2 logs
  493  pm2 logs --err
  494  ls
  495  pm2
  496  pm2 ls
  497  pm2 logs
  498  pm2 logs --err
  499  ./generar_tasa.sh
  500  ls
  501  cd apps/
  502  ls
  503  cd sisprot-online/
  504  ls
  505  source .venv/bin/activate
  506  import requests
  507  python
  508  ls
  509  git pull origin main
  510  git config pull.rebase false
  511  git pull origin main
  512  git status
  513  git log
  514  git pull origin master
  515  cd ..
  516  ls
  517  cd °
  518  cd ~
  519  ls
  520  ./generar_tasa.sh
  521  psql -h localhost -U sisprot -d sisprot_db
  522  ls
  523  cd apps/
  524  ls
  525  cd sisprot-online/
  526  ls
  527  git pull origin master
  528  pm2 ls
  529  pm2 restart sisprot_online
  530  pm2 logs
  531  ls
  532  cd apps/
  533  ls
  534  cd sisprot-online/
  535  ls
  536  git pull origin master
  537  ls
  538  pm2 restart sisprot_online
  539  pm2 logs
  540  psql -h localhost -U sisprot -d sisprot_db
  541  cat /etc/nginx/sites-available/
  542  cd /etc/nginx/sites-available/
  543  ls
  544  cat default
  545  nano default
  546  sudo nano default
  547  sudo nginx -t
  548  sudo systemctl restart nginx
  549  sudo systemctl status nginx
  550  ls
  551  cd apps/
  552  ls
  553  cd sisprot-online/
  554  git pull origin master
  555  pm2 restart sisprot_online
  556  pm2 logs
  557  pm2 restart sisprot_online
  558  pm2 logs
  559  git pull origin master
  560  pm2 restart sisprot_online
  561  git pull origin master
  562  pm2 restart sisprot_online
  563  psql -h localhost -U sisprot -d sisprot_db
  564  clear
  565  psql -h localhost -U sisprot -d sisprot_db
  566  cd /etc/nginx/sites-available/
  567  ls
  568  cat default
  569  nano default
  570  sudo nano default
  571  sudo nginx -t
  572  sudo nginx -s reload
  573  ls
  574  cd apps/sisprot-online/
  575  ls
  576  git pull origin master
  577  pm2 restart sisprot_online
  578  pm2 logs
  579  pm2 restart sisprot_online
  580  pm2 logs
  581  code .
  582  git pull origin master
  583  pm2 restart sisprot_online
  584  pm2 logs
  585  ls
  586  pm2 logs
  587  pm2 logs --err
  588  cd apps/sisprot-online/
  589  ls
  590  git pull origin master
  591  pm2 restart sisprot_online
  592  psql -h localhost -U sisprot -d sisprot_db
  593  ls
  594  cd apps/
  595  ls
  596  cd sisprot-online/
  597  ls
  598  git pull origin master
  599  pm2 restart sisport_online
  600  pm2
  601  pm2 ls
  602  pm2 restart sisprot_online
  603  pm2 logs
  604  ls
  605  cd apps/
  606  ls
  607  cd sisprot-online/
  608  ls
  609  git pull origin
  610  ls
  611  pm2 logs --err
  612  pm2 logs
  613  exit
  614  psql -h localhost -U sisprot -d sisprot_db
  615  pm2 logs
  616  pm2 logs --err
  617  pm2 logs
  618  cd
  619  cd .pm2
  620  ls
  621  cd logs
  622  ls
  623  less sisprot-online-error.log
  624  psql -h localhost -U sisprot -d sisprot_db
  625  pm2 logs
  626  psql -h localhost -U sisprot -d sisprot_db
  627  SELECT count(*) FROM clientes;
  628  SELECT * FROM clientes;
  629  SELECT count(*) FROM clientes WHERE estado_cliente = 'activo';
  630  psql -h localhost -U sisprot -d sisprot_db
  631  ls
  632  cd apps/sisprot-online/
  633  git pull origin master
  634  pm2 restart
  635  pm2 ls
  636  pm restart sisprot_online
  637  pm2 restart sisprot_online
  638  pm2 logs
  639  pm2 restart sisprot_online
  640  pm2 logs
  641  git pull origin master
  642  pm2 logs --err
  643  psql -h localhost -U sisprot -d sisprot_db
  644  ls
  645  pm2
  646  pm2 ls
  647  pm2 stop sisprot_online
  648  git pull origin master
  649  cd apps/sisprot-online/
  650  ls
  651  git pull origin master
  652  pm2 start sisprot_online
  653  pm2 logs
  654  psql -h localhost -U sisprot -d sisprot_db
  655  ls
  656  pm2 logs 360control_backend --err
  657  pm2 logs sisprot_online --err
  658  exit
  659  ls
  660  cd apps/
  661  ls
  662  cd sisprot-online/
  663  git pull origin master
  664  pm2 restart
  665  pm2 restart sisprot_online
  666  pm2 logs --err
  667  pm2 logs
  668  git pull origin master
  669  pm2 logs --err
  670  git status
  671  git pull origin master
  672  pm2 restart sisprot_online
  673  pm2 logs
  674  git pull origin master
  675  pm2 restart sisprot_online
  676  pm2 logs
  677  git status
  678  git pull origin master
  679  pm2 restart sisprot_online
  680  pm2 logs --err
  681  git pull origin master
  682  pm2 restart sisprot_online
  683  pm2 logs --err
  684  pm2 restart sisprot_online
  685  git pull origin master
  686  pm2 logs --err
  687  git pull origin master
  688  pm2 restart sisprot_online
  689  psql -h localhost -U sisprot -d sisprot_db
  690  ls
  691  cd apps/
  692  ls
  693  cd sisprot-online/
  694  git pull origin master
  695  ls
  696  pm2 restart sisprot_online
  697  pm2 logs
  698  psql -h localhost -U sisprot -d sisprot_db
  699  pm2 logs --err
  700  ls
  701  cd apps/
  702  ls
  703  cd sisprot-online/
  704  ls
  705  git pull origin master
  706  ls
  707  pm2 restart sisprot_online
  708  pm2 logs
  709  cd ../
  710  ls
  711  deactivated
  712  exit
  713  ls
  714  pm2 logs
  715  exit
  716  ls
  717  cd apps/
  718  ls
  719  cd sisprot-online/
  720  ls
  721  git status
  722  git push backend master
  723  git remote -v
  724  git pull origin master
  725  pm2 restart
  726  pm2 restart all
  727  ls
  728  cd apps/
  729  ls
  730  cd sisprot-online/
  731  git pull origin main
  732  git pull origin master
  733  pm2 restart sisprot_online
  734  pm2 logs --err
  735  ls
  736  pm2
  737  ls
  738  cd apps/
  739  ls
  740  cd sisprot-online/
  741  ls
  742  git pull origin master
  743  pm2 restart sisprot_backend
  744  pm2 ls
  745  pm2 resatart sisprot_online
  746  pm2 restart sisprot_online
  747  pm2 logs
  748  ls
  749  cd apps/
  750  ls
  751  cd sisprot-online/
  752  git pull origin main
  753  git pull origin master
  754  pm2 restart sisprot-backend
  755  pm2 ls
  756  pm2 restart sisprot_online
  757  pm2 ls
  758  pm2 logs
  759  git pull origin master
  760  pm2 restart sisport_online
  761  pm2 ls
  762  pm2 restart sisprot_online
  763  ls
  764  git pull origin master
  765  pm2 restart sisprot_online
  766  pm2 logs
  767  ls
  768  pm2 logs
  769  ls
  770  cd apps/
  771  ls
  772  cd sisprot-online/
  773  git pull origin
  774  pm2
  775  pm2 restart all
  776  pm2 logs
  777  ls
  778  cd apps/
  779  ls
  780  cd sisprot-online/
  781  git pull origin master
  782  pm2 restart all
  783  pm2 logs
  784  pm2 logs -errr
  785  pm2 logs --err
  786  ls
  787  cd apps/
  788  ls
  789  cd sisprot-online/
  790  git pull origin master
  791  pm2 restart all
  792  ls
  793  cd apps/
  794  ls
  795  cd sisprot-online/
  796  git pull origin master
  797  pm2 restart all
  798  ls
  799  cd apps/
  800  ls
  801  cd sisprot-online/
  802  git pull origin master
  803  pm2 restart all
  804  pm2 logs
  805  pm2 logs --err
  806  less .pm2/logs/sisprot-online-error.log
  807  ls
  808  cd apps/
  809  ls
  810  cd sisprot-online/
  811  ls
  812  git status
  813  git pull origin master
  814  pm2 restart all
  815  pm2 logs
  816  pm2 logs sisprot_online
  817  ls
  818  cd apps/sisprot-online/
  819  git pull origin master
  820  pm2 restart all
  821  pm2 logs
  822  git log
  823  psql -h localhost
  824  psql -h localhost -d sisprot_db -u sisprot
  825  psql -h localhost -d sisprot_db -U sisprot
  826  psql -h localhost -d sisprot_db -U sisprot -p 5432
  827  ifconfig
  828  ls
  829  cd apps/
  830  ls
  831  cd sisprot-online/
  832  ls
  833  git pull origin master
  834  pm2 restart all
  835  ls
  836  cd apps/
  837  ls
  838  cd sisprot-online/
  839  git pull origin master
  840  pm2 restart all
  841  pm2 logs --err
  842  less .pm2/logs/sisprot-online-error.log
  843  ls
  844  cd apps/
  845  ls
  846  cd sisprot-online/
  847  git pull origin master
  848  pm2 restart all
  849  pm2 logs
  850  pm2 logs --err
  851  ls
  852  cd apps/
  853  ls
  854  cd sisprot-online/
  855  ls
  856  git pull origin master
  857  pm2 restart all
  858  ls
  859  cd apps/
  860  ls
  861  cd sisprot-online/
  862  git pull origin master
  863  pm2 restart all
  864  ls
  865  cd apps/
  866  cd sisprot-online/
  867  ls
  868  git pull origin master
  869  pm2 restart all
  870  pm2 logs
  871  ls
  872  cd apps/
  873  ls
  874  cd sisprot-online/
  875  git pull origin master
  876  pm2 restart
  877  pm2 restart all
  878  ls
  879  cd apps/
  880  ls
  881  cd sisprot-online/
  882  ls
  883  git pull origin master
  884  pm2 restart all
  885  git pull origin master
  886  pm2 restart all
  887  pm2 logs --err
  888  less .pm2/logs/sisprot-online-error.log
  889  ls
  890  cd apps/
  891  ls
  892  cd sisprot-online/
  893  ls
  894  git pull origin master
  895  pm2 restart all
  896  pm2 logs
  897  ls
  898  cd apps/
  899  ls
  900  pm2 logs --err
  901  ls
  902  cd sisprot-online/
  903  git pull origin master
  904  pm2 restart all
  905  ls
  906  cd apps/
  907  ls
  908  cd sisprot-online/
  909  pm2 logs --err
  910  cd
  911  less .pm2/logs/sisprot-online-error.log
  912  cd apps/
  913  ls
  914  cd sisprot-online/
  915  ls
  916  git pull origin master
  917  pm2 restart all
  918  ls
  919  cd apps/
  920  ls
  921  cd sisprot-online/
  922  ls
  923  git pull origin master
  924  pm2 restart all
  925  pm2 logs --err
  926  pm2 restart all
  927  pm2 logs --err
  928  ls
  929  source .venv/bin/activate
  930  ls
  931  pwd
  932  pm2 ls
  933  cd ~/apps/sisprot-online
  934  ls
  935  git pull origin main
  936  git pull origin master
  937  pm2 restart sisprot_online
  938  pm2 logs sisprot_online
  939  ls
  940  mkdir static
  941  cd /etc/nginx/sites-enabled/
  942  ls
  943  cat default
  944  cd ../sites-enabled/
  945  ls
  946  cat default
  947  vim default
  948  sudo vim default
  949  cd
  950  cd apps/sisprot-online/
  951  pwd
  952  cd static/
  953  pwd
  954  sudo vim /etc/nginx/sites-enabled/default
  955  touch texto.html
  956  nano texto.html
  957  sudo nginx -t
  958  sudo systemctl restart nginx
  959  sudo systemctl status nginx
  960  ls
  961  sudo nano /etc/nginx/sites-enabled/default
  962  sudo vim /etc/nginx/sites-enabled/default
  963  sudo nginx -t
  964  sudo nginx reload
  965  sudo vim /etc/nginx/sites-enabled/default
  966  sudo nginx -t
  967  ls
  968  sudo systemctl restart nginx
  969  cd ..
  970  chmod 777 static/
  971  ls -a
  972  ls
  973  cd static/
  974  ls
  975  sui
  976  sudo vim /etc/nginx/sites-enabled/default
  977  sudo nginx -t
  978  touch prueba.txt
  979  sudo systemctl restart nginx
  980  sudo systemctl status nginx
  981  nginx
  982  sudo nginx
  983  ls
  984  sudo vim /etc/nginx/sites-enabled/
  985  sudo vim /etc/nginx/sites-enabled/default
  986  sudo vim /etc/nginx/sites-enabled/app
  987  less /etc/nginx/sites-enabled/default
  988  sudo vim /etc/nginx/sites-enabled/app
  989  sudo nginx -t
  990  sudo systemctl restart nginx
  991  cd /etc/nginx/sites-enabled/
  992  less app
  993  sudo chown -R :www-data /home/software/apps/sisprot-online/static/
  994  ls
  995  cd
  996  ls
  997  cd apps/
  998  ls
  999  cd sisprot-online/
 1000  ls
 1001  cd static/
 1002  ls
 1003  cd ..
 1004  rm -d -r static/
 1005  mkdir static
 1006  cd static/
 1007  echo Hola > prueba.txt
 1008  cd ..
 1009  sudo chown -R :www-data /home/software/apps/sisprot-online/static
 1010  ls
 1011  cd s
 1012  cd static/
 1013  ls
 1014  pwd
 1015  sudo usermod -a -G software www-data
 1016  who
 1017  sudo nano /etc/nginx/sites-enabled/app
 1018  sudo systemctl restart nginx
 1019  sudo systemctl status nginx
 1020  sudo systemctl status nginx -l
 1021  ls
 1022  cd ..
 1023  ls
 1024  cd /var/www/html/
 1025  ls
 1026  touch prueba.txt
 1027  cd ..
 1028  ls -a
 1029  ls -la
 1030  cd html/
 1031  ls
 1032  sudo touch prueba.txt
 1033  pwd
 1034  sudo nano /etc/nginx/sites-enabled/app
 1035  sudo nginx -t
 1036  sudo systemctl restart nginx
 1037  ls
 1038  nginx -v
 1039  nginx ---version
 1040  sudo nano /etc/nginx/nginx.conf
 1041  sudo nano /etc/nginx/sites-enabled/app
 1042  sudo usermod -a -G software www-data
 1043  cd
 1044  ls
 1045  cd apps/
 1046  ls
 1047  cd sisprot-online/
 1048  sudo chown -R www-data:www-data static
 1049  sudo chown www-data:www-data static
 1050  sudo systemctl restart nginx
 1051  cd static/
 1052  ls
 1053  cd ..
 1054  ls
 1055  ls -la
 1056  sudo nano /etc/nginx/sites-enabled/app
 1057  sudo nginx -t
 1058  sudo systemctl restart nginx
 1059  ls
 1060  ls -la
 1061  ls
 1062  cd static/
 1063  ls
 1064  touch prueba3.txt
 1065  ls
 1066  cd ..
 1067  ls
 1068  cd static/
 1069  cd ..
 1070  ls -la
 1071  cd static/
 1072  sudo touch prueba2.txt
 1073  sudo chown www-data:www-data prueba2.txt
 1074  cd ..
 1075  ls
 1076  cd sisprot-online/
 1077  ls
 1078  mkdir media
 1079  ls
 1080  cd static/
 1081  ls
 1082  rm prueba2.txt
 1083  sudo prueba2.txt
 1084  sudo rm prueba2.txt
 1085  ls
 1086  sudo rm prueba.txt
 1087  sudo mkdir prospectos
 1088  ls
 1089  cd ..
 1090  ls -la
 1091  sudo nano /etc/nginx/nginx.conf
 1092  cat .env
 1093  ls
 1094  history
 1095  history |grep git
 1096  ls
 1097  ls l
 1098  ls -l
 1099  cd apps/
 1100  ls
 1101  ls -l
 1102  ls
 1103  cd sisprot-online/
 1104  ls
 1105  ls -l
 1106  git status
 1107  ls -slash
 1108  cd .git/
 1109  ls
 1110  cat config
 1111  cd ..
 1112  ls
 1113  cd ..
 1114  ls
 1115  cd sisprot-online/
 1116  ls
 1117  history
 1118  history |grep git
 1119  ls
 1120  cd sisprot/
 1121  ls
 1122  cd models/
 1123  ls
 1124  vi models.py
 1125  history
 1126  clear
 1127  ls
 1128  ls -l
 1129  history
 1130  clear
 1131  uname -a
 1132  free
 1133  df -tH
 1134  df -Th
 1135  history